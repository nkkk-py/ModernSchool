package com.example.modern_school

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
